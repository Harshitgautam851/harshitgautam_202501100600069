# Q1 — Student Class (5 marks)

**Paper requirement:** Create a student class containing studentId, studentName, email,
courseName, programmingScore, mathScore, and a list of technical skills. Use encapsulation,
constructors, getters/setters, and appropriate object methods.

## File
`Student.java`

## How it satisfies each requirement

- **Encapsulation**: every field is `private`; the only way to read/write them from outside the
  class is through the public getters/setters.
- **Constructors**: a no-arg constructor (required by JPA) and an all-args constructor for
  convenience.
- **Getters/setters**: one pair per field.
- **Appropriate object methods** (beyond plain getters/setters): `getAverageScore()`,
  `getPerformanceCategory()`, `getStrongerSubject()` — these are computed business-logic methods
  that live on the object itself, since they're derived purely from the object's own data
  (`programmingScore` and `mathScore`).
- `studentId` is `Integer` (not primitive `int`) — this matters when the object is built from a
  JSON request body that omits the id (see Q3's PUT endpoint); a primitive can never represent
  "no value supplied."

## Note on JPA annotations
`@Entity`, `@Table`, `@Id`, `@ElementCollection` etc. are present because this same class is also
the database table definition (used in Q2) — in a pure "Q1 only" context these can be ignored;
they don't change the OOP structure the question is asking for.
