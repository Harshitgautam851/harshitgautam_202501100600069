# Q2 — Database + Business Logic (5 marks)

**Paper requirement:** Create a suitable MySQL database/tables and implement: average score,
performance category, stronger subject, search by id/email/course, merit list sorted descending,
students with same skills, weak-programming-but-strong-math filter, duplicate ID prevention +
score validation (0-100).

## Files
- `schema.sql` — the actual MySQL tables (exported live from the running database via
  `SHOW CREATE TABLE`). `student` holds the main record; `student_skills` is a separate linked
  table for the skills list (one row per student per skill, foreign key back to `student`).
- `StudentRepository.java` — Spring Data JPA interface giving `save()`, `findAll()`, `findById()`,
  `existsById()`, `deleteById()` for free, backed by the tables above.
- `StudentService.java` — all 8 business requirements, implemented here.
- `StudentNotFoundException.java`, `DuplicateStudentException.java`, `InvalidScoreException.java`
  — custom exceptions, one per business rule violation, thrown here and turned into HTTP status
  codes in the controller (see Q3).

## Requirement → method mapping

| Paper requirement | Method in StudentService |
|---|---|
| 1. Average score | `Student.getAverageScore()` (on the entity, used throughout) |
| 2. Performance category | `Student.getPerformanceCategory()` |
| 3. Stronger subject | `Student.getStrongerSubject()` |
| 4. Search by ID/email/course | `search(Integer id, String email, String course)` |
| 5. Merit list sorted descending | `getMeritList()` |
| 6. Students with same skills | `getStudentsWithSameSkills()` |
| 7. Weak programming, strong math | `getNeedsImprovementInProgrammingButStrongInMath()` |
| 8. Duplicate ID + score validation | `addStudent()` + `validateScore()` |

## How the database actually gets created
The tables are NOT created by running `schema.sql` manually — Hibernate auto-generates them from
the `Student.java` entity annotations on first run (`spring.jpa.hibernate.ddl-auto=update` in
`application.properties`). `schema.sql` is included here as documentation of the resulting schema,
and can also be run directly in MySQL Workbench to recreate the tables from scratch if needed.
