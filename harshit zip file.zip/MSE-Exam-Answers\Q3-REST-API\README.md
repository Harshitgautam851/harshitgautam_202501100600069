# Q3 — REST APIs (10 marks)

**Paper requirement:** Using Spring Boot, develop REST APIs for: add a student, retrieve all
students, search for a student by ID, update student scores and skills, delete a student record,
display the merit list.

## Files
- `StudentController.java` — all endpoints.
- `Student-API.postman_collection.json` — 17 ready-made requests covering every endpoint and edge
  case (success + not-found + duplicate + invalid-score). Import this into Postman to demo.

## Endpoint → requirement mapping

| # | Requirement | Method | Endpoint |
|---|---|---|---|
| 1 | Add a student | POST | `/students` |
| 2 | Retrieve all students | GET | `/students` |
| 3 | Search for a student by ID | GET | `/students/{id}` (also `/students/search?id=&email=&course=`) |
| 4 | Update student scores and skills | PUT | `/students/{id}` |
| 5 | Delete a student record | DELETE | `/students/{id}` |
| 6 | Display the merit list | GET | `/students/merit-list` |

Two extra endpoints expose the remaining Q2 business rules as REST too, so they can be demoed
live rather than only explained:
- `GET /students/same-skills`
- `GET /students/needs-improvement-programming`

## Status codes used (and why)
- `201 Created` — successful POST
- `200 OK` — successful GET/PUT
- `204 No Content` — successful DELETE (nothing to return)
- `404 Not Found` — id doesn't exist (GET/PUT/DELETE)
- `409 Conflict` — POST with a duplicate id
- `400 Bad Request` — POST/PUT with a score outside 0-100

## How to run this yourself
1. Build the full project in `../../student-management-system/` (this folder only has copies of
   the relevant files for easy reading — the actual buildable Maven project is there).
2. `mvnw.cmd clean package`, then `java -jar target/student-management-system-0.0.1-SNAPSHOT.jar --server.port=8081`
3. Import `Student-API.postman_collection.json` into Postman and run the requests in order.
