# MSE 2 Exam Answers — CS336B Object Oriented Prog. Using Java
## Student Profile and Skill Development Management System

Organized to match the question paper exactly:

- **`Q1-Student-Class/`** — the `Student` entity (5 marks)
- **`Q2-Database-BusinessLogic/`** — MySQL schema + all 8 business rules (5 marks)
- **`Q3-REST-API/`** — all 6 REST endpoints + Postman collection (10 marks)
- **`VIVA-PREP.md`** — full explanation + likely viva Q&A for this paper
- **`AI-PROMPTS-AND-REFLECTIONS.md`** — the required Moodle deliverable (3 AI prompts + reflections)

Each `Q*` folder has its own `README.md` mapping every paper requirement to the exact method/
endpoint that implements it.

## Important: this folder is for reading/submission clarity only
The files here are **copies**, organized by question for easy grading/reading. The actual
buildable, runnable Maven project (with `pom.xml`, `mvnw`, all files together as Spring Boot
expects) lives at:

```
..\student-management-system\
```

That's what you build and run for the live demo:
```bash
cd ..\student-management-system
.\mvnw.cmd clean package
java -jar target\student-management-system-0.0.1-SNAPSHOT.jar --server.port=8081
```

**For Moodle submission**, zip the `src/` folder of `student-management-system/` (the real,
complete, buildable source) along with `AI-PROMPTS-AND-REFLECTIONS.md` — not this folder, since
this one has the files split apart for readability rather than in their real package structure.
