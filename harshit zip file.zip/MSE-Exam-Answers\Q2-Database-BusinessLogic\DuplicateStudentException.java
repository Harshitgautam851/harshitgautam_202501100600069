package com.exam.student;

public class DuplicateStudentException extends RuntimeException {
    public DuplicateStudentException(int id) {
        super("Student already exists with id: " + id);
    }
}
