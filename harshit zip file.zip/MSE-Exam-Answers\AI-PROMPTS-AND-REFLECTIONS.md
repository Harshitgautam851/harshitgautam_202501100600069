# Three AI Prompts and Reflections — Student Profile and Skill Development Management System

## Prompt 1
**Prompt:** "Create a Student entity for a Spring Boot + MySQL system with studentId, studentName,
email, courseName, programmingScore, mathScore, and a list of technical skills. Use encapsulation,
constructors, getters/setters, and add methods for average score, performance category (Excellent
85+, Good 70-84.99, Satisfactory 50-69.99, Needs Improvement below 50), and stronger subject."

**Reflection:** The AI generated the `Student` JPA entity with `@Entity`, `@Id`, and an
`@ElementCollection` for the skills list (since a List field needs its own linked table in a
relational database, not a plain column). It also suggested computing `averageScore`,
`performanceCategory`, and `strongerSubject` as **methods on the entity itself** rather than as
separate stored fields — this was a good call since these values depend only on the stored scores
and would go stale if stored separately. I kept this design because it avoids data duplication and
keeps the business rules close to the data they operate on, which is a core OOP principle
(encapsulation).

## Prompt 2
**Prompt:** "Now build the service layer and REST controller implementing: search by ID/email/
course, a merit list sorted descending by average, grouping students who share the same technical
skills, a filter for students weak in programming but strong in math, duplicate-ID prevention, and
score validation (0-100). Expose add/get-all/search/update/delete/merit-list as REST endpoints."

**Reflection:** The AI used Java Streams and Collections (`Comparator`, `TreeSet`, `HashMap`,
`stream().filter()/.sorted()/.collect()`) for the business logic instead of writing complex SQL —
this matches the problem statement's explicit requirement to "use Java collections." I noticed the
"same skills" grouping used a `TreeSet<String>` as a map key to normalize skill order before
comparing — I asked why, and the reasoning was that two students with skills listed in different
order (e.g. `["Java","SQL"]` vs `["SQL","Java"]`) should still be recognized as the same skill set;
a `TreeSet` sorts them consistently so they hash/equal the same way. I verified this understanding
is correct and kept the approach.

## Prompt 3
**Prompt:** "Test every endpoint against the live MySQL database using Postman/Newman, including
the duplicate-ID, invalid-score, and not-found edge cases, and fix any bugs found."

**Reflection:** This testing pass actually caught a real bug: `studentId` was declared as a
primitive `int` in both the entity field and its all-args constructor. A PUT request's JSON body
correctly omits `studentId` (since it comes from the URL path, not the body) — but Spring Boot
compiles with `-parameters`, so Jackson automatically used the all-args constructor during
deserialization and tried to bind `null` into the primitive `int` parameter, crashing with
`400 Bad Request`. I had seen this exact bug pattern before (same issue in an earlier Spring Boot
practice exercise), so I immediately recognized the fix: change the field and constructor parameter
to the wrapper type `Integer`, which can legally be `null`. After the fix, I reran the full 17-request/
26-assertion test suite and all passed. This reinforced for me that `int` vs `Integer` is not a
cosmetic choice in Java — it directly affects whether a field can represent "no value," which
matters a lot when an object is partially constructed from external data like a JSON request body.
