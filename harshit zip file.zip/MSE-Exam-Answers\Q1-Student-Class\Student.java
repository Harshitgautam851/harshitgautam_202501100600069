package com.exam.student;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "student")
public class Student {

    @Id
    private Integer studentId;

    private String studentName;
    private String email;
    private String courseName;
    private double programmingScore;
    private double mathScore;

    @ElementCollection
    @CollectionTable(name = "student_skills", joinColumns = @JoinColumn(name = "student_id"))
    @Column(name = "skill")
    private List<String> skills = new ArrayList<>();

    public Student() {
    }

    public Student(Integer studentId, String studentName, String email, String courseName,
                    double programmingScore, double mathScore, List<String> skills) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.email = email;
        this.courseName = courseName;
        this.programmingScore = programmingScore;
        this.mathScore = mathScore;
        this.skills = skills != null ? skills : new ArrayList<>();
    }

    // Object method: average score (business logic kept on the entity itself)
    public double getAverageScore() {
        return (programmingScore + mathScore) / 2.0;
    }

    // Object method: performance category derived from average
    public String getPerformanceCategory() {
        double avg = getAverageScore();
        if (avg >= 85) return "Excellent";
        if (avg >= 70) return "Good";
        if (avg >= 50) return "Satisfactory";
        return "Needs Improvement";
    }

    // Object method: which subject this student is stronger in
    public String getStrongerSubject() {
        if (programmingScore > mathScore) return "Programming";
        if (mathScore > programmingScore) return "Mathematics";
        return "Equal";
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public double getProgrammingScore() {
        return programmingScore;
    }

    public void setProgrammingScore(double programmingScore) {
        this.programmingScore = programmingScore;
    }

    public double getMathScore() {
        return mathScore;
    }

    public void setMathScore(double mathScore) {
        this.mathScore = mathScore;
    }

    public List<String> getSkills() {
        return skills;
    }

    public void setSkills(List<String> skills) {
        this.skills = skills;
    }
}
