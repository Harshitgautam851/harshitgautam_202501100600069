package com.exam.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Service
public class StudentService {

    @Autowired
    private StudentRepository repository;

    private void validateScore(double score, String fieldName) {
        if (score < 0 || score > 100) {
            throw new InvalidScoreException(fieldName + " must be between 0 and 100, got: " + score);
        }
    }

    // 8. Prevent duplicate student IDs and validate scores between 0 and 100
    public Student addStudent(Student student) {
        if (repository.existsById(student.getStudentId())) {
            throw new DuplicateStudentException(student.getStudentId());
        }
        validateScore(student.getProgrammingScore(), "Programming score");
        validateScore(student.getMathScore(), "Mathematics score");
        return repository.save(student);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    public Student getStudentById(int id) {
        return repository.findById(id).orElseThrow(() -> new StudentNotFoundException(id));
    }

    // 4. Search for students by ID, email or course
    public List<Student> search(Integer id, String email, String course) {
        List<Student> all = repository.findAll();
        return all.stream()
                .filter(s -> id == null || s.getStudentId() == id)
                .filter(s -> email == null || s.getEmail().equalsIgnoreCase(email))
                .filter(s -> course == null || s.getCourseName().equalsIgnoreCase(course))
                .collect(Collectors.toList());
    }

    public Student updateStudent(int id, Student updated) {
        Student existing = getStudentById(id);
        validateScore(updated.getProgrammingScore(), "Programming score");
        validateScore(updated.getMathScore(), "Mathematics score");
        existing.setProgrammingScore(updated.getProgrammingScore());
        existing.setMathScore(updated.getMathScore());
        if (updated.getSkills() != null) {
            existing.setSkills(updated.getSkills());
        }
        if (updated.getStudentName() != null) existing.setStudentName(updated.getStudentName());
        if (updated.getEmail() != null) existing.setEmail(updated.getEmail());
        if (updated.getCourseName() != null) existing.setCourseName(updated.getCourseName());
        return repository.save(existing);
    }

    public void deleteStudent(int id) {
        if (!repository.existsById(id)) {
            throw new StudentNotFoundException(id);
        }
        repository.deleteById(id);
    }

    // 5. Generate a merit list sorted by average score in descending order
    public List<Student> getMeritList() {
        return repository.findAll().stream()
                .sorted(Comparator.comparingDouble(Student::getAverageScore).reversed())
                .collect(Collectors.toList());
    }

    // 6. Identify students who have the same technical skills
    // Groups students by their exact skill set (order-independent), using a Map internally
    // (Set as key so skill order doesn't matter), then returns only groups with more than one student.
    public List<List<Student>> getStudentsWithSameSkills() {
        List<Student> all = repository.findAll();
        Map<Set<String>, List<Student>> grouped = new HashMap<>();

        for (Student s : all) {
            Set<String> skillSet = new TreeSet<>(s.getSkills()); // TreeSet normalizes order for comparison
            grouped.computeIfAbsent(skillSet, k -> new ArrayList<>()).add(s);
        }

        List<List<Student>> result = new ArrayList<>();
        for (Map.Entry<Set<String>, List<Student>> entry : grouped.entrySet()) {
            if (!entry.getKey().isEmpty() && entry.getValue().size() > 1) {
                result.add(entry.getValue());
            }
        }
        return result;
    }

    // 7. Students who need improvement in programming (score < 50) but math score >= 75
    public List<Student> getNeedsImprovementInProgrammingButStrongInMath() {
        return repository.findAll().stream()
                .filter(s -> s.getProgrammingScore() < 50 && s.getMathScore() >= 75)
                .collect(Collectors.toList());
    }
}
