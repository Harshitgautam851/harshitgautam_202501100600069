package com.exam.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService service;

    // 1. Add a student
    @PostMapping
    public ResponseEntity<Student> addStudent(@RequestBody Student student) {
        Student saved = service.addStudent(student);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // 2. Retrieve all students
    @GetMapping
    public List<Student> getAllStudents() {
        return service.getAllStudents();
    }

    // 3. Search for a student by ID (plus bonus: by email or course via query params)
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable int id) {
        return service.getStudentById(id);
    }

    @GetMapping("/search")
    public List<Student> search(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String course) {
        return service.search(id, email, course);
    }

    // 4. Update student scores and skills
    @PutMapping("/{id}")
    public Student updateStudent(@PathVariable int id, @RequestBody Student updated) {
        return service.updateStudent(id, updated);
    }

    // 5. Delete a student record
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable int id) {
        service.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }

    // 6. Display the merit list
    @GetMapping("/merit-list")
    public List<Student> getMeritList() {
        return service.getMeritList();
    }

    // Extra: same-skills grouping and needs-improvement filter, per the problem statement
    @GetMapping("/same-skills")
    public List<List<Student>> getStudentsWithSameSkills() {
        return service.getStudentsWithSameSkills();
    }

    @GetMapping("/needs-improvement-programming")
    public List<Student> getNeedsImprovementInProgramming() {
        return service.getNeedsImprovementInProgrammingButStrongInMath();
    }

    @ExceptionHandler(StudentNotFoundException.class)
    public ResponseEntity<String> handleNotFound(StudentNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }

    @ExceptionHandler(DuplicateStudentException.class)
    public ResponseEntity<String> handleDuplicate(DuplicateStudentException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
    }

    @ExceptionHandler(InvalidScoreException.class)
    public ResponseEntity<String> handleInvalidScore(InvalidScoreException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    }
}
