# Viva Prep — Student Profile and Skill Development Management System

## Project structure (what each file does)

- **Student.java** — JPA entity = the data model + table definition.
  - `@Entity` + `@Table(name="student")` — maps this class to a MySQL table.
  - `@Id private Integer studentId` — primary key. Wrapper type `Integer` (not `int`) so it can
    be `null` when Jackson builds a partial object (e.g. a PUT body without an id).
  - `@ElementCollection` on `skills` — a `List<String>` can't fit in one column, so Hibernate
    creates a SEPARATE table `student_skills(student_id, skill)` linked by foreign key.
  - `getAverageScore()`, `getPerformanceCategory()`, `getStrongerSubject()` — computed business
    logic methods living on the entity. Not stored in the DB; calculated fresh every time from
    `programmingScore`/`mathScore`. Jackson automatically includes them in JSON responses because
    they're public `getX()` methods.

- **StudentRepository.java** — `extends JpaRepository<Student, Integer>`. Gives free
  `save()`, `findAll()`, `findById()`, `existsById()`, `deleteById()` without writing any SQL —
  Spring Data JPA generates the implementation at runtime.

- **StudentService.java** — business logic layer. Talks to the repository, applies rules, uses
  Java Collections (Streams, Comparator, Map, Set, TreeSet) to do filtering/sorting/grouping in
  Java rather than SQL.

- **StudentController.java** — REST layer. Translates HTTP requests into service calls and Java
  objects into JSON responses. Also has `@ExceptionHandler` methods that catch custom exceptions
  and turn them into proper HTTP status codes (404/409/400).

- **3 custom exceptions** (StudentNotFoundException, DuplicateStudentException,
  InvalidScoreException) — each represents one specific business rule violation. Thrown in the
  service, caught in the controller, turned into the right HTTP status.

## How the 8 business requirements (Q2) are implemented

1. **Average score** — `(programmingScore + mathScore) / 2.0`, a method on `Student`.
2. **Performance category** — if/else chain on the average: ≥85 Excellent, ≥70 Good, ≥50
   Satisfactory, else Needs Improvement.
3. **Stronger subject** — compares `programmingScore` vs `mathScore` directly.
4. **Search by ID/email/course** — `StudentService.search()`: loads all students via the
   repository, then uses `.stream().filter(...)` three times (each filter only applies if that
   parameter was actually given — `id == null || ...`), demonstrating Java Streams.
5. **Merit list sorted descending** — `.stream().sorted(Comparator.comparingDouble(Student::
   getAverageScore).reversed())`. `Comparator` + method reference is the idiomatic Java way to
   sort by a computed value.
6. **Same technical skills** — builds a `Map<Set<String>, List<Student>>`: for each student, the
   key is a `TreeSet` of their skills (sorted, so order doesn't matter for comparison); students
   land in the same map bucket if they have an identical skill set. Only buckets with more than
   one student are kept and returned. This is the most "Collections-heavy" part of the project —
   good to explain in detail if asked.
7. **Weak in programming, strong in math** — one filter: `programmingScore < 50 && mathScore >=
   75`.
8. **Duplicate ID + score validation** — `addStudent()` checks `repository.existsById(id)` first
   (throws `DuplicateStudentException` → HTTP 409 Conflict if true), then validates both scores
   are between 0–100 (throws `InvalidScoreException` → HTTP 400 if not), only then saves.

## How the 6 REST endpoints (Q3) work

| # | Endpoint | What it does |
|---|---|---|
| 1 | `POST /students` | Adds a student (runs duplicate+validation checks first) |
| 2 | `GET /students` | Returns every student |
| 3 | `GET /students/{id}` | Looks up one by id (404 if missing) — also `GET /students/search?id=&email=&course=` for the other search modes |
| 4 | `PUT /students/{id}` | Updates scores/skills/other fields of an existing student |
| 5 | `DELETE /students/{id}` | Removes a student (404 if missing) |
| 6 | `GET /students/merit-list` | Returns all students sorted by average score, descending |

Plus two extra endpoints for the specific business rules that don't fit neatly into basic CRUD:
`GET /students/same-skills` and `GET /students/needs-improvement-programming`.

## Likely viva questions

**Q: Why is studentId an Integer (wrapper) and not int (primitive) even though it's always required?**
A: Because Jackson (the JSON library Spring uses) builds a `Student` object from incoming request
bodies. A PUT request's body correctly omits `studentId` (it comes from the URL path), so when
Jackson tries to construct the object, it needs to be able to assign `null` to that field
temporarily. A primitive `int` can never be `null` in Java, so this would crash with a
`400 Bad Request` — which is exactly the bug I found and fixed during testing.

**Q: Why is skills a separate table instead of a column?**
A: Standard relational databases don't have a native "list" column type — a `VARCHAR` column holds
one value, not a list. JPA's `@ElementCollection` solves this by automatically creating a child
table (`student_skills`) with a foreign key back to `student`, one row per skill. This is a
classic one-to-many relationship, just auto-managed by Hibernate instead of written by hand.

**Q: Why put averageScore/performanceCategory/strongerSubject as methods instead of database columns?**
A: They're fully derived from `programmingScore` and `mathScore` — storing them separately would
risk them becoming stale/wrong if someone updates the scores but forgets to recalculate. Computing
them on demand guarantees they're always correct. This is also more normalized database design
(no redundant data).

**Q: Explain the "same skills" grouping in detail.**
A: For each student, I build a `TreeSet<String>` from their skill list — a `TreeSet` both removes
duplicates and sorts the elements, so two students with the same skills in different input order
still produce an equal set. I use that set as the key in a `HashMap<Set<String>, List<Student>>`
and group students into their bucket with `computeIfAbsent(...).add(student)`. At the end, I only
keep buckets where the list has more than 1 student — a group of 1 means nobody else shares that
exact skill set, so it's not interesting.

**Q: Why HTTP 409 for duplicate ID and 400 for invalid score, not just one generic error?**
A: They're semantically different kinds of failure. 409 Conflict means the request conflicts with
the current state of the server (a record with that id already exists). 400 Bad Request means the
request itself was malformed/invalid (a score outside 0–100 is invalid input, regardless of
server state). Using the correct status code lets any client distinguish "retry with a different
id" from "fix your input data" without parsing the error message text.

**Q: What's the difference between @ExceptionHandler methods and a try/catch in the controller method?**
A: `@ExceptionHandler` centralizes error handling — instead of wrapping every controller method in
try/catch, I throw plain exceptions from the service layer, and Spring automatically routes any
thrown exception of that type to the matching handler method, anywhere it's thrown from. This
keeps the controller methods focused only on the "happy path" logic.

**Q: Where does Spring Data JPA's findAll()/save()/deleteById() actually come from — did you write them?**
A: No — `StudentRepository` just extends `JpaRepository<Student, Integer>`, an interface with no
method bodies. Spring Data JPA generates a real implementation of this interface at startup using
a dynamic proxy, based on the entity's `@Id` type and table mapping. This is why I didn't write any
raw SQL in this project — Hibernate/JPA translates these calls into SQL automatically.

**Q: How would you add a feature to filter students by a specific skill (e.g. "find all Java programmers")?**
A: Add a new method in `StudentService`:
```java
public List<Student> findBySkill(String skill) {
    return repository.findAll().stream()
        .filter(s -> s.getSkills().contains(skill))
        .collect(Collectors.toList());
}
```
and a matching `@GetMapping("/by-skill")` endpoint in the controller that calls it, reading the
skill name from a `@RequestParam`.
